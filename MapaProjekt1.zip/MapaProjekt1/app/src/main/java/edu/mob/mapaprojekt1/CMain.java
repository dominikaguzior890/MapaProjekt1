package edu.mob.mapaprojekt1;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.location.LocationListenerCompat;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnSuccessListener;

import java.util.List;
import java.util.Locale;

public class CMain extends AppCompatActivity {

    private static final int PERMISSIONS_FINE_LOCATION = 99;
    protected TextView tvLat;
    protected TextView tvLon;
    protected TextView tvAlt;
    protected TextView tvAdress;
    Button btnNewWayPoint;
    Button btnWayPointList;
    Button btnShowMap;
    //Switch swLocationUpdates;

    //nw czy potzrebne jeszcze
    boolean updateOn = false;

    Location currentLocation;
    List<Location> savedLocations;

    LocationRequest locationRequest;

    FusedLocationProviderClient fusedLocationProviderClient;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvLat = findViewById(R.id.tvLat);
        tvLon = findViewById(R.id.tvLon);
        tvAlt = findViewById(R.id.tvAlt);
        tvAdress = findViewById(R.id.tvAdress);
        //swLocationUpdates = findViewById(R.id.swLocationUpdates);
        btnNewWayPoint = findViewById(R.id.btnNewWayPoint);
        btnWayPointList = findViewById(R.id.btnWayPointList);
        btnShowMap = findViewById(R.id.btnShowMap);

        locationRequest = new LocationRequest();
        locationRequest.setInterval(1000 * 30);
        locationRequest.setFastestInterval(1000 * 5);
        locationRequest.setPriority(LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY);
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(CMain.this);

        updateGPS();

        btnNewWayPoint.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CMyApp myApp = (CMyApp) getApplicationContext();
                savedLocations = myApp.getMyLocations();
                savedLocations.add(currentLocation);

            }
        });

        btnWayPointList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(CMain.this, CListLocation.class);
                startActivity(i);
            }
        });

        btnShowMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(CMain.this, CMapa.class);
                startActivity(i);
            }
        });
    }



    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch (requestCode) {
            case PERMISSIONS_FINE_LOCATION:
                ;
                if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    updateGPS();
                } else {
                    Toast.makeText(this, "This app requires permission to be granted in order to work properly", Toast.LENGTH_SHORT).show();
                    finish();
                }
                break;
        }
    }


    //poczytac o tym fused - czy to potrzebne

    private void updateGPS() {
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(CMain.this);
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            fusedLocationProviderClient.getLastLocation().addOnSuccessListener(this, new OnSuccessListener<Location>() {
                @Override
                public void onSuccess(Location location) {
                    //updateUIValues(location);
                    currentLocation = location;


                }
            });
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, PERMISSIONS_FINE_LOCATION);
            }
        }
    }




    private void updateUIValues(Location location) {

//        tvLat.setText(String.valueOf(location.getLatitude()));
//        tvLon.setText(String.valueOf(location.getLongitude()));
//
//
//        if (location.hasAltitude()) {
//            tvAlt.setText(String.valueOf(location.getAltitude()));
//        }else{
//            tvAlt.setText("Niedostępne");
//        }
//
//        Geocoder geocoder = new Geocoder(MainActivity.this);
//        try {
//            List<Address> addresses = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
//            tvAdress.setText(addresses.get(0).getAddressLine(0));
//        }catch(Exception e){
//            tvAdress.setText("Nie można zwrócić adresu");

        CMyApp myApp = (CMyApp) getApplicationContext();
        savedLocations = myApp.getMyLocations();
    }


}



